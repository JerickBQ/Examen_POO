class Comercial:Empleado {
public string Nombre {get;set;}
public string Edad {get;set;}
public int Salario {get;set;}
public double Comision {get;set;}
public Comercial (string Nombre, string edad, string Salario,double Comision):base (Nombre,edad,Salario){
this.Nombre=Nombre;
this.Edad=Edad;
this.Salario;
thhis.Comision;
}
public int PLus (){
PLus=300;
}
public override Nombre(){
   if  (Edad > 30 && Comision > 200)

    Salario =Salario+PLus;
Console.writeline("El salario es:"+ Salario);
Console.writeline("Sueldo del Empleado Comercial ");
 
}


}


