﻿internal class Program{
    private static void Main(string[] args)
    {
        Comercial.c1=new Comercial(Ronald,35,1000);
        Repartidor.R1=new Repartidor(Alansito,24,1000);




    }
}
