class Repartidor:Empleado{
public string Nombre {get;set;}
public string Edad {get;set;}
public int Salario {get;set;}
public string Zona {get;set;}
public Repartidor (string Nombre, string edad, string Salario, string Zona):base (Nombre,edad,Salario){
this.Nombre=Nombre;
this.Edad=Edad;
this.Salario=Salario;
this.Zona=Zona;
}
public int PLus (){
PLus=300;
}
public override condicion2 (){

if  (Edad <25 && Zona == Zona3)

    Salario =Salario+PLus;
Console.writeline("Sueldo del Empleado Repartidor ");
Console.writeline("El salario es:", Salario);

}

}








