class Empleado{
public string Nombre {get;set;}
public string Edad {get;set;}
public int Salario {get;set;}
public Empleado (string Nombre, string edad, string Salario, int Comision){
this.Nombre=Nombre;
this.Edad=Edad;
this.Salario=Salario;
}
public int PLus (){
PLus=300;

}



}